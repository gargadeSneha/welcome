//
//  CustomCVC2.swift
//  Activity Indicator
//
//  Created by TryCatch Classes on 29/06/1944 Saka.
//

import UIKit

class CustomCVC2: UICollectionViewCell {
    
    @IBOutlet weak var imgviewcell2: UIImageView!
    
    @IBOutlet weak var labelviewcell2: UILabel!
}
