//
//  WelcomeVC.swift
//  Activity Indicator
//
//  Created by TryCatch Classes on 19/09/22.
//

import UIKit

class WelcomeVC: UIViewController {

    @IBOutlet weak var welcomeImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

            }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        welcomeImg.isHidden = true
        do {
           sleep(3)
        }
        let wellimg = storyboard?.instantiateViewController(withIdentifier: "CollcetionCategoriesVC") as! CollcetionCategoriesVC
        self.navigationController?.pushViewController(wellimg, animated: true)
    }

}
