//
//  CustomCVC.swift
//  Activity Indicator
//
//  Created by TryCatch Classes on 29/06/1944 Saka.
//

import UIKit

class CustomCVC: UICollectionViewCell {
    
    @IBOutlet weak var celllabelView: UILabel!
    
    @IBOutlet weak var cellimgView: UIImageView!
    
}
