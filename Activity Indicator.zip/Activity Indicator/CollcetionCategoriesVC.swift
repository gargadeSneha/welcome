//
//  CollcetionCategoriesVC.swift
//  Activity Indicator
//
//  Created by TryCatch Classes on 19/09/22.
//

import UIKit

class CollcetionCategoriesVC: UIViewController {

    @IBOutlet weak var menuimg: UIImageView!
    @IBOutlet weak var navigationLabel: UINavigationBar!
    @IBOutlet weak var textvoice: UIImageView!
    @IBOutlet weak var textimgview: UIImageView!
    @IBOutlet weak var textView: UITextField!
    @IBOutlet weak var labelview: UIView!
    @IBOutlet weak var collectionview: UICollectionView!
    
    @IBOutlet weak var collectionView2: UICollectionView!
    @IBOutlet weak var newArrivals: UILabel!
    
    
    
    @IBOutlet weak var collectionView3: UICollectionView!
    @IBOutlet weak var recommLabel: UILabel!
    
    
    var LabelName1 = ["Women","Men","Kids","Electronics","Beauty"]
    var ImgName1 = ["Women","Men","Kids","Electronics","Beauty"]
    
    var labelName2 = ["Bags","Laptops","Watches","Mobile Covers"]
    var ImgName2 = ["Bags","Laptops","Watches","Mobile Covers"]
    
    var labelName3 = ["Shoes","Handbags & Clutches","Hair Oil","Watch Combo","Deoderants","Car Air Fresheners","Sofa Sets","Sandels & floaters","Mobiles","Books"]
    var ImgName3 = ["Shoes","Handbags & Clutches","Hair Oil","Watch Combo","Deoderants","Car Air Fresheners","Sofa Sets","Sandels & floaters","Mobiles","Books"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
      
       
        collectionview.delegate = self
        collectionview.dataSource = self
        
        collectionView2.dataSource = self
        collectionView2.delegate = self
         
        collectionView3.dataSource = self
        collectionView3.delegate = self
        
    }
    
    @IBAction func view1BtnTapped(_ sender: UIButton) {
        let btnv1 = storyboard?.instantiateViewController(withIdentifier: "View1VC") as! View1VC
        self.navigationController?.pushViewController(btnv1, animated:  true)
    }
    
    @IBAction func view2BtnTapped(_ sender: UIButton) {
        let btnv2 = storyboard?.instantiateViewController(withIdentifier: "View2VC") as! View2VC
        self.navigationController?.pushViewController(btnv2, animated: true)
    }
    
    
}
extension CollcetionCategoriesVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (collectionView == collectionview){
            return LabelName1.count
        }
        else if (collectionView == collectionView2)
        {
            return labelName2.count
        }
        else
        {
            return 10
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCVC
        
        if (collectionView == collectionView2){
            let cell2 = collectionView2.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! CustomCVC2
            cell2.labelviewcell2.text = labelName2[indexPath.row]
            cell2.imgviewcell2.image = UIImage(named: ImgName2[indexPath.row])
            cell2.layer.cornerRadius = 10
            return cell2
        }else if (collectionView == collectionView3) {
            let cell3 = collectionView3.dequeueReusableCell(withReuseIdentifier: "cell3", for: indexPath) as! CustomCVC3
              cell3.celllabel3.text = labelName3[indexPath.row]
              cell3.cellimg3.image = UIImage(named: ImgName3[indexPath.row])
              cell3.layer.cornerRadius = 10
            return cell3

        }
        
        cell.cellimgView.image = UIImage(named: ImgName1[indexPath.row])
        cell.celllabelView.text = LabelName1[indexPath.row]
        cell.layer.cornerRadius = 10
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if (collectionView == collectionView3)
        {
             let width = ((collectionView3.frame.width - 15 ) / 2 )
             let heigth = ((collectionView3.frame.width - 15 ) / 2 )
             return CGSize(width: width, height: heigth)
        }
        
        let width = ((collectionView.frame.width - 20 ) / 3 )
        let heigth = ((collectionView.frame.width - 10) / 1 )
        
        return CGSize(width: width, height: heigth)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 5
        
    }
}

