//
//  CustomCVC3.swift
//  Activity Indicator
//
//  Created by TryCatch Classes on 30/06/1944 Saka.
//

import UIKit

class CustomCVC3: UICollectionViewCell {
    
    @IBOutlet weak var celllabel3: UILabel!
    @IBOutlet weak var cellimg3: UIImageView!
}
